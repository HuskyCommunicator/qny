def transcribe_audio(audio_bytes: bytes) -> str:
    """最小占位：将二进制长度作为文本返回。"""
    return f"len={len(audio_bytes)}"


